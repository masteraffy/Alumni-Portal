<?php
$con=mysqli_connect('localhost','database_username','database_password','database_name');
?>